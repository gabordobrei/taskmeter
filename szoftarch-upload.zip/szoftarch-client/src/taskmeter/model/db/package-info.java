/**
 * 
 */
/**
 * @author Gabor Dobrei
 * @version 1.0
 * @since Nov 15, 2013
 */
package taskmeter.model.db;